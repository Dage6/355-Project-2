// Get reference to the tags container and textarea
const tagsEl = document.getElementById('tags');
const textareaEl = document.getElementById('textarea');

// Focus on the textarea by default
textareaEl.focus();

// Listen for keyup event on textarea
textareaEl.addEventListener('keyup', (e) => {
    // Create tags based on input value separated by commas
    createTags(e.target.value);

    // If Enter key is pressed, clear textarea and select a random tag
    if (e.key === 'Enter') {
        setTimeout(() => {
            e.target.value = '';
        }, 10);
        randomSelect();
    }
});

// Function to create tags based on input value
function createTags(input) {
    const tags = input.split(',').filter(tag => tag.trim() !== '').map(tag => tag.trim()); // Trim whitespace
    tagsEl.innerHTML = ''; // Clear existing tags
    // Create and append span elements for each tag
    tags.forEach(tag => {
        const tagEl = document.createElement('span');
        tagEl.classList.add('tag');
        tagEl.innerText = tag;
        tagsEl.appendChild(tagEl);
    });
}

// Function to randomly select a tag and highlight it
function randomSelect() {
    const times = 30;
    const interval = setInterval(() => {
        const randomTag = pickRandomTag();
        highlightTag(randomTag);
        setTimeout(() => {
            unhighlightTag(randomTag);
        }, 100);
    }, 100);
    setTimeout(() => {
        clearInterval(interval);
        setTimeout(() => {
            const randomTag = pickRandomTag();
            highlightTag(randomTag);
        }, 100);
    }, times * 100);
}

// Function to pick a random tag
function pickRandomTag() {
    const tags = document.querySelectorAll('.tag');
    return tags[Math.floor(Math.random() * tags.length)];
}

// Function to highlight a tag
function highlightTag(tag) {
    tag.classList.add('highlight');
}

// Function to remove highlight from a tag
function unhighlightTag(tag) {
    tag.classList.remove('highlight');
}

// Counter animation
const counter = document.querySelectorAll('.counter');
counter.forEach(counter => {
    counter.innerText = '0';
    const updateCounter = () => {
        const target = +counter.getAttribute('data-target');
        const c = +counter.innerText;
        const increment = target / 2000;
        if (c < target) {
            counter.innerText = `${Math.ceil(c + increment)}`;
            setTimeout(updateCounter, 1);
        } else {
            counter.innerText = target;
        }
    };
    updateCounter();
});

// Function to toggle chat visibility
function toggleChat() {
    const chatBody = document.getElementById('chat-body');
    chatBody.style.display = chatBody.style.display === 'none' ? 'block' : 'none';
}

// Function to send a message and receive a response
function sendMessage(message) {
    const chatMessages = document.getElementById('chat-messages');
    // Create user message
    const userMessageDiv = document.createElement('div');
    userMessageDiv.className = 'message user-message';
    const userBubble = document.createElement('div');
    userBubble.className = 'bubble';
    userBubble.innerText = message;
    const userName = document.createElement('span');
    userName.className = 'name';
    userName.innerText = 'You';
    userMessageDiv.appendChild(userBubble);
    userMessageDiv.appendChild(userName);
    chatMessages.appendChild(userMessageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Simulate bot response after 1 second
    setTimeout(() => {
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'message bot-message';
        const botBubble = document.createElement('div');
        botBubble.className = 'bubble';
        let botResponse = '';
        switch (message) {
            case 'What is your restaurant name?':
                botResponse = 'Our restaurant name is "We Happy Restaurant"';
                break;
            case 'What do you recommend?':
                botResponse = 'Please try our chef recommendations';
                break;
            case 'I do not know what to order':
                botResponse = 'Please use the random choice selector to decide';
                break;
            default:
                botResponse = 'I do not understand';
        }
        botBubble.innerText = botResponse;
        const botName = document.createElement('span');
        botName.className = 'name';
        botName.innerText = 'Bot';
        botMessageDiv.appendChild(botName);
        botMessageDiv.appendChild(botBubble);
        chatMessages.appendChild(botMessageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 1000);
}

// Function to clear chat messages
function clearChat() {
    const chatMessages = document.getElementById('chat-messages');
    chatMessages.innerHTML = '';
}
