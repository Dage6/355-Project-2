// Selecting elements from the DOM
const loadText = document.querySelector('.loading-text'); // Element displaying loading percentage
const bg = document.querySelector('body'); // Body element

// Initialize load variable
let load = 0;

// Set interval for blurring effect
let int = setInterval(blurring, 10);

// Function to blur the background
function blurring() {
    load++;

    // Clear interval when loading reaches 100%
    if (load > 99) {
        clearInterval(int);
    }

    // Update loading text and opacity
    loadText.innerText = `${load}%`;
    loadText.style.opacity = scale(load, 0, 100, 1, 0);
    bg.style.filter = `blur(${scale(load, 0, 100, 30, 0)}px)`;
}

// Function to scale a number from one range to another
function scale(number, inMin, inMax, outMin, outMax) {
    return (number - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
}

// Function to create fireworks
function createFirework() {
    const firework = document.createElement('div'); // Create a new div element
    firework.classList.add('firework'); // Add CSS class for styling
    firework.style.left = Math.random() * window.innerWidth + 'px'; // Random horizontal position
    firework.style.top = Math.random() * window.innerHeight + 'px'; // Random vertical position
    document.body.appendChild(firework); // Append the firework to the body

    // Remove the firework after animation
    setTimeout(() => {
        firework.remove();
    }, 1000);
}

// Create fireworks every 1 second
setInterval(createFirework, 1000);

// Array of sound effects
const sounds = ['fireworks'];

// Iterate over sound effects
sounds.forEach(sound => {
    const btn = document.createElement('button'); // Create a new button element
    btn.classList.add('btn'); // Add CSS class for styling
    btn.innerText = sound; // Set button text
    
    // Add event listener to play sound effect on button click
    btn.addEventListener('click', () => {
        document.getElementById(sound).play();
    });

    // Append button to the buttons container
    document.getElementById('buttons').appendChild(btn);
});

// Function to stop playing all songs
function stopSongs() {
    sounds.forEach(sound => {
        const song = document.getElementById(sound);
        sound.pause(); // Pause the sound
        song.currentTime = 0; // Reset playback to start
    });
}
