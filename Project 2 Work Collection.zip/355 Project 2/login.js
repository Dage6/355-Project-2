// Function to handle user signup
async function signup() {
    // Get username and password input values
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;

    // Send POST request to '/signup' endpoint with user data
    const response = await fetch('/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });

    // Get the response and display the message to the user
    const result = await response.json();
    document.getElementById('message').textContent = result.message;
}

// Function to handle user login
async function login() {
    // Get username and password input values
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    // Send POST request to '/login' endpoint with user data
    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });

    // Get the response and display the message or welcome message based on login status
    const result = await response.json();
    if (result.message === 'Login successful') {
        displayWelcomeMessage();
    } else {
        document.getElementById('message').textContent = result.message;
    }
}

// Function to display a welcome message after successful login
function displayWelcomeMessage() {
    const container = document.querySelector('.container');
    container.innerHTML = '<div class="welcome-message">Welcome back, please use member code "11756" at checkout</div>';
}

// Function to switch to the signup form
function showSignupForm() {
    document.getElementById('login-form').classList.remove('active');
    document.getElementById('signup-form').classList.add('active');
}

// Function to switch to the login form
function showLoginForm() {
    document.getElementById('signup-form').classList.remove('active');
    document.getElementById('login-form').classList.add('active');
}
