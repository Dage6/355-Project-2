const express = require('express');  // Import Express framework
const fs = require('fs').promises;  // Import file system module with promises
const path = require('path');  // Import path module for handling file paths

const app = express();  // Create an Express application
const PORT = 3000;  // Define the port to run the server
const USERS_FILE = path.join(__dirname, 'users.txt');  // Path to the users file

app.use(express.json());  // Middleware to parse JSON request bodies
app.use(express.static(__dirname));  // Serve static files from the root directory

// Route to serve the main index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname,'index.html'));
});

// Route to serve the index.html file
app.get('/index', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Route to serve the menu.html file
app.get('/menu', (req, res) => {
    res.sendFile(path.join(__dirname, 'menu.html'));
});

// Route to serve the login.html file
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// Route to serve the credit.html file
app.get('/credit', (req, res) => {
    res.sendFile(path.join(__dirname, 'credit.html'));
});

// Route to handle user signup
app.post('/signup', async (req, res) => {
    const { username, password } = req.body;
    const users = await readUsers();

    // Check if the username already exists
    if (users.some(user => user.username === username)) {
        return res.json({ message: 'Username already exists' });
    }

    // Add the new user and save to the file
    users.push({ username, password });
    await writeUsers(users);
    res.json({ message: 'Signup successful' });
});

// Route to handle user login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const users = await readUsers();

    // Check if the user exists and password matches
    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
        res.json({ message: 'Login successful' });
    } else {
        res.json({ message: 'Username or password is incorrect' });
    }
});

// Function to read users from the file
async function readUsers() {
    try {
        const data = await fs.readFile(USERS_FILE, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        return [];  // Return an empty array if there is an error (e.g., file not found)
    }
}

// Function to write users to the file
async function writeUsers(users) {
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2));
}

// Start the server and listen on the specified port
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
