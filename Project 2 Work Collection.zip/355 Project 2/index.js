// Get reference to the image container, left button, and right button
const imgs = document.getElementById('imgs');
const leftBtn = document.getElementById('left');
const rightBtn = document.getElementById('right');

// Get all images inside the image container
const img = document.querySelectorAll('#imgs img');

// Initialize index variable
let idx = 0;

// Set interval to change images automatically every 2 seconds
let interval = setInterval(run, 2000);

// Function to change image
function run() {
    idx++;
    changeImage();
}

// Function to change image and handle boundary conditions
function changeImage() {
    if (idx > img.length - 1) {
        idx = 0;
    } else if (idx < 0) {
        idx = img.length - 1;
    }
    // Translate the image container horizontally to show the next image
    imgs.style.transform = `translateX(${-idx * 500}px)`;
}

// Function to reset the interval when a button is clicked
function resetInterval() {
    clearInterval(interval);
    interval = setInterval(run, 2000);
}

// Event listener for the right button to show the next image
rightBtn.addEventListener('click', () => {
    idx++;
    changeImage();
    resetInterval();
});

// Event listener for the left button to show the previous image
leftBtn.addEventListener('click', () => {
    idx--;
    changeImage();
    resetInterval();
});
